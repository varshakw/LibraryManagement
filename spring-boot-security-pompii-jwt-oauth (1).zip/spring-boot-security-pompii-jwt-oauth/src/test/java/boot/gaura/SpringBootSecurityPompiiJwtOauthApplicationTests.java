package boot.gaura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSecurityPompiiJwtOauthApplicationTests {

	@Test
	void contextLoads() {
	}

}
