package com.spring.books.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootBooksApplicationTests {

	@Test
	void contextLoads() {
	}

}
