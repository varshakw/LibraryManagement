package com.spring.books.api.repository;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.CountQuery;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.spring.books.api.model.Book;

@Repository
public interface BookRepository extends MongoRepository<Book, String>
{
	@Query("{'bookId' : ?0}")
	public Book findByBookId(String bookId);
	
}
