package com.spring.books.api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.spring.books.api.model.Book;
import com.spring.books.api.repository.BookRepository;

import ch.qos.logback.core.status.Status;

@RestController
public class BookController {
	
	
	
	@Autowired
	private BookRepository bookRepository;
	
	@GetMapping("/books")
	public @ResponseBody List<Book> getBooks()
	{
		return bookRepository.findAll();
		
	}
	
	@GetMapping("/books/{bookId}")
	public @ResponseBody Book getBookById( @PathVariable(value="bookId") String bookId)
	{
		return bookRepository.findByBookId(bookId);
	}
	
	@PostMapping("/books/{bookId}/{userAction}")
	public @ResponseBody Book updateBookDetails( @PathVariable(value="bookId") String bookId, @PathVariable(value="userAction") int userAction)
	{
			Book book = getBookById(bookId);
			int availableCopies = 0, totalCopies = 0 , subscribedCopies = 0;
			
			if(book == null)
				throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Book not found for id :"+bookId);
			else	
			{
				availableCopies = book.getAvailableCopies();
				totalCopies = book.getTotalCopies();
				subscribedCopies = totalCopies - availableCopies;
			}
			
			switch(userAction) {
				case 1:
				// subscribe
					if ( availableCopies > 0 ) 	
					{
						book.setAvailableCopies( availableCopies - 1);
						bookRepository.save(book);
					} else {
						throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No subscriptions available for this book.");
					}
					break;
				case -1:
				// return
					if (subscribedCopies <=0 ) {
						throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No subscription available for return operation");
					}
					book.setAvailableCopies( availableCopies + 1);
					bookRepository.save(book);
				break;
				default:
					throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Incorrect input given");
			}
		
			return book;
				
	}
}
