package com.spring.subscriptions.api.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="subscriptions")
public class Subscriptions {

	@Id
	private String id;
	
	private String name;
	
	private Date subscribedDate;
	
	private Date returnedDate;
	
	private String bookId;

	public Subscriptions(String name, Date subscribedDate, Date returnedDate, String bookId) {
		super();
		this.name = name;
		this.subscribedDate = subscribedDate;
		this.returnedDate = returnedDate;
		this.bookId = bookId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getSubscribedDate() {
		return subscribedDate;
	}

	public void setSubscribedDate(Date subscribedDate) {
		this.subscribedDate = subscribedDate;
	}

	public Date getReturnedDate() {
		return returnedDate;
	}

	public void setReturnedDate(Date returnedDate) {
		this.returnedDate = returnedDate;
	}

	public String getBookId() {
		return bookId;
	}

	public void setBookId(String bookId) {
		this.bookId = bookId;
	}
	
	
	
	
}
