package com.spring.subscriptions.api.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.spring.subscriptions.api.model.Subscriptions;

public interface SubscriptionRepository extends MongoRepository<Subscriptions, String> {
	
	@Query("{'name' : ?0 , 'bookId' :?1 , 'returnedDate' : null }")
	public List<Subscriptions> findActiveSubscribtionByNameAndBookId( String name, String bookId);
	
	@Query("{'name' : ?0}")
	public List<Subscriptions> findBySubscriberName( String name);

}
