package com.spring.subscriptions.api.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import com.spring.subscriptions.api.model.Subscriptions;
import com.spring.subscriptions.api.repository.SubscriptionRepository;

@RestController
public class SubscriptionController {
	
	@Autowired
	private SubscriptionRepository subscriptionRepository;
	
	@Autowired
	private RestTemplate restTemplate;
	   	
	@GetMapping("/subscriptions")
	public ResponseEntity<?> getSubscriptions(@PathVariable ( required = false) String name)
	{
		List<Subscriptions> subscription;
		if (name != null)
			subscription = subscriptionRepository.findBySubscriberName(name);
		else
			subscription = subscriptionRepository.findAll();
		
		if (subscription.isEmpty())
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<> (subscription, HttpStatus.OK);
	}
	
	@PostMapping("/subscriptions")
	private ResponseEntity<Subscriptions> save(@RequestBody Subscriptions subscription) 
	{
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> httpEntity = new HttpEntity<>(headers);
		String uri = "http://BookService/books/";
		restTemplate.exchange(uri + "/{bookId}/1",
                 org.springframework.http.HttpMethod.POST,
                 httpEntity,
                 String.class,
                 subscription.getBookId());	
		 
		 return new ResponseEntity<Subscriptions>(subscriptionRepository.save(subscription), HttpStatus.CREATED);
	}
	
	@PostMapping("/returns")
	private ResponseEntity<Subscriptions> update(@RequestBody Subscriptions subscription) 
	{
		List<Subscriptions> subscriptions =  subscriptionRepository.findActiveSubscribtionByNameAndBookId(subscription.getName(), subscription.getBookId());
    	System.out.println("List size :"+subscriptions.size());
		
		if (subscriptions.isEmpty())
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Susbcription not found. ");
		else if (subscriptions.size() > 1 )
			throw new ResponseStatusException(HttpStatus.CONFLICT, "Susbcription does not exists for this book. ");

		
		Subscriptions existingSubscription = subscriptions.get(0);

		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> httpEntity = new HttpEntity<>(headers);
		String uri = "http://BookService/books/";
		restTemplate.exchange(uri + "/{bookId}/-1",
                 org.springframework.http.HttpMethod.POST,
                 httpEntity,
                 String.class,
                 subscription.getBookId());	
		
		existingSubscription.setReturnedDate(subscription.getReturnedDate());
		
		return new ResponseEntity<Subscriptions>(subscriptionRepository.save(existingSubscription), HttpStatus.CREATED);
	}
	
	@Bean
	@LoadBalanced
	public RestTemplate restTemplate()
	{
		HttpComponentsClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory();
	    clientHttpRequestFactory.setConnectTimeout(30000);
	    clientHttpRequestFactory.setConnectionRequestTimeout(30000);
	    clientHttpRequestFactory.setReadTimeout(30000);
	    
	    return new RestTemplate(clientHttpRequestFactory);
	}


}
