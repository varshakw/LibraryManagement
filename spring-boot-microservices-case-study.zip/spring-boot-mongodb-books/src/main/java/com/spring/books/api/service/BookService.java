package com.spring.books.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.spring.books.api.model.Book;
import com.spring.books.api.repository.BookRepository;

@Service
public class BookService {

	@Autowired
	BookRepository bookRepository;
	
	public List<Book> findAll()
	{
		return bookRepository.findAll();
	}
	
	@Cacheable(value="books",key="#bookId")
	public Book findByBookId(String bookId)
	{
		System.out.println("Cache value added for "+bookId);
		return bookRepository.findByBookId(bookId);
	}
	
	@CachePut(cacheNames = "books",key = "#book.bookId",condition = "#result != null")
	public Book updateBook(Book book, int userAction)
	{
		int	availableCopies = book.getAvailableCopies();
		int	totalCopies = book.getTotalCopies();
		int	subscribedCopies = totalCopies - availableCopies;
		
		switch(userAction) {
			case 1:
			// subscribe
				if ( availableCopies > 0 ) 	
				{
					book.setAvailableCopies( availableCopies - 1);
					bookRepository.save(book);
				} else {
					throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No subscriptions available for this book.");
				}
				break;
			case -1:
			// return
				if (subscribedCopies <=0 ) {
					throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No subscription available for return operation");
				}
				book.setAvailableCopies( availableCopies + 1);
				bookRepository.save(book);
				break;
			default:
				throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Incorrect input given");
		}
		System.out.println("Cache updated for "+book.getBookId());

		return book;
	}
}

