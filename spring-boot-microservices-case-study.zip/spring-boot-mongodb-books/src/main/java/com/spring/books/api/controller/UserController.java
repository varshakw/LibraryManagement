package com.spring.books.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.spring.books.api.model.User;
import com.spring.books.api.repository.UserRepository;

@RestController
@RequestMapping("/users")
public class UserController {
		
	@Autowired
	UserRepository userRepository;
	
	@PostMapping("/register")
	public ResponseEntity<?> processRegistration(@RequestBody User user)
	{
		User existingUser = userRepository.findByName(user.getName());
		
		if (existingUser == null)
		{	
			userRepository.save(user);
			return new ResponseEntity<User>(HttpStatus.CREATED);
		}
		else
		{
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"User '"+existingUser.getName() + "' already exists");
		}
		
	}

}
