package com.spring.books.api.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.spring.books.api.model.Book;

@Repository
public interface BookRepository extends MongoRepository<Book, String>
{
	@Query("{'bookId' : ?0}")
	public Book findByBookId(String bookId);
	
}
