package com.spring.books.api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.spring.books.api.model.Book;
import com.spring.books.api.service.BookService;

@RestController
public class BookController {
		
	@Autowired
	BookService bookService;
	
	@GetMapping("/books")
	public List<Book> getBooks()
	{
		return bookService.findAll();
	}
	
	@GetMapping("/books/{bookId}")
	public ResponseEntity<Book> getBookById( @PathVariable(value="bookId") String bookId)
	{
	   Book book = bookService.findByBookId(bookId);
    		
    	if (book == null)
    		return new ResponseEntity<> (HttpStatus.NOT_FOUND);

    	return new ResponseEntity<Book> (book, HttpStatus.OK);
    }
	
	@PostMapping("/books/{bookId}/{userAction}")
	public ResponseEntity<Book> updateBookDetails( @PathVariable(value="bookId") String bookId, @PathVariable(value="userAction") int userAction)
	{
			Book book = bookService.findByBookId(bookId);
			
			if(book == null)
				throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Book not found for id :"+bookId);
			else	
				bookService.updateBook(book, userAction);
		
			return new ResponseEntity<Book>(book, HttpStatus.CREATED);
	}
}