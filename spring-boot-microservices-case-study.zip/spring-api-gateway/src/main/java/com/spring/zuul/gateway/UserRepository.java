package com.spring.zuul.gateway;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface UserRepository extends MongoRepository<Subscriber, String> {

	@Query("{'name':?0}")
	public Subscriber findByName(String name);
}
